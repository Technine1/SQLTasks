-- Скрипт создания таблиц для MySQL
CREATE TABLE Departments (
    DepartmentID INT PRIMARY KEY,
    DepartmentName VARCHAR(100) NOT NULL
);
-- Остальная часть структуры см. в описании выше
